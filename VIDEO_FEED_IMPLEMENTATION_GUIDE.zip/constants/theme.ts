// theme.ts
import { Platform, useColorScheme } from "react-native";

type ThemeColors = {
  text: string;
  background: string;
  surface: string;
  tint: string;
  icon: string;
  border: string;
};

const tintColorLight = "#0a7ea4";
const tintColorDark = "#ffffff";

export const Colors: { light: ThemeColors; dark: ThemeColors } = {
  light: {
    text: "#11181C",
   // background: "#ffffff",
    background: "#ffffff",
    surface: "#f7f8fa",
    tint: tintColorLight,
    icon: "#687076",
    border: "#E5E7EB",
  },
  dark: {
    text: "#ECEDEE",
    background: "#151718",
    surface: "#1e1f20",
    tint: tintColorDark,
    icon: "#9BA1A6",
    border: "#2d2d2f",
  },
};

/**
 * Use this hook to get stable theme colors.
 * It only returns "light" or "dark" (safe fallback to "dark").
 */
export function useThemeColors(): ThemeColors {
  const scheme = useColorScheme();
  // Normalize: only 'light' or 'dark' are accepted. Fallback to dark.
  const normalized = scheme === "light" ? "light" : "light";
  return Colors[normalized];
}

/**
 * Font families for each platform.
 * Adjust these if you have custom fonts loaded in your project.
 */
export const Fonts = Platform.select({
  ios: {
    sans: "System",
    serif: "Georgia",
    rounded: "SF Pro Rounded",
    mono: "Menlo",
  },
  android: {
    sans: "Roboto",
    serif: "serif",
    rounded: "sans-serif",
    mono: "monospace",
  },
  web: {
    sans:
      "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded:
      "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono:
      "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
  default: {
    sans: "System",
    serif: "serif",
    rounded: "System",
    mono: "monospace",
  },
}) as {
  sans: string;
  serif: string;
  rounded: string;
  mono: string;
};
