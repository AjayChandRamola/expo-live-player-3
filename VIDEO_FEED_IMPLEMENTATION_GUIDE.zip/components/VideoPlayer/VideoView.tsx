// components/VideoPlayer/VideoView.tsx
/* 
  Dependencies:
    - expo-av
    - react-native
  Renders expo-av <Video /> and surfaces events to parent handlers.
*/
import React from "react";
import * as RN from "react-native";
import { Video, AVPlaybackStatus, VideoFullscreenUpdate } from "expo-av";
import type { VideoViewProps } from "./types";

const VideoView: React.FC<VideoViewProps> = ({
  videoRef,
  sourceUrl,
  onPlaybackStatusUpdate,
  onFullscreenUpdate,
  onLoad,
  onError,
  onVideoAreaPress,
  resizeMode = "contain",
}) => {
  return (
    <RN.TouchableOpacity
      activeOpacity={1}
      style={[{ width: "100%", height: "100%" }]}
      onPress={onVideoAreaPress}
      accessibilityLabel="Video area"
      accessibilityHint="Tap to toggle controls. Double-tap left or right to seek 10 seconds."
    >
      <Video
        ref={videoRef}
        style={{ width: "100%", height: "100%" }}
        source={{ uri: sourceUrl }}
        resizeMode={resizeMode}
        useNativeControls={false}
        onPlaybackStatusUpdate={onPlaybackStatusUpdate}
        onFullscreenUpdate={onFullscreenUpdate}
        onLoad={onLoad}
        onError={onError}
        accessibilityLabel="Video content"
      />
    </RN.TouchableOpacity>
  );
};

export default React.memo(VideoView);
