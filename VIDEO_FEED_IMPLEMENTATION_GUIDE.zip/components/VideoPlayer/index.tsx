/**
 * components/VideoPlayer/index.tsx
 *
 * Full VideoPlayer integrating:
 * - expo-av Video
 * - usePlayPauseController for center Play/Pause overlay behavior
 * - PlayPauseButton presentational component
 *
 * Backwards-compatible props preserved:
 * - default export is VideoPlayer component
 *
 * Key behaviors implemented:
 * - Center Play/Pause button visible initially ~3s, auto-hide when playing
 * - Auto-hide resumes after play/resume
 * - Single-tap toggles (visible / hide) with paused-stays-visible rule
 * - Double-tap quick-seek preserved (heuristic detection)
 * - Defensive programming and observability (structured logs)
 *
 * Dependencies: react, react-native, expo-av, @expo/vector-icons
 */

import React, { useCallback, useRef, useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  GestureResponderEvent,
  Text,
  StatusBar,
  Dimensions,
  Platform,
  Modal,
  SafeAreaView,
} from "react-native";
import { Video, AVPlaybackStatus } from "expo-av";
import * as ScreenOrientation from "expo-screen-orientation";
import PlayPauseButton from "./PlayPauseButton";
import { PreviousVideoButton } from "./PreviousVideoButton";
import { NextVideoButton } from "./NextVideoButton";
import { MinimizeButton } from "./MinimizeButton";
import AutoplayToggle from "./AutoplayToggle";
import AutoplayNotification from "./AutoplayNotification";
import FullscreenButton from "./FullscreenButton";
import { usePlayPauseController } from "./usePlayPauseController";

type Props = {
  sourceUrl: string;
  autoplay?: boolean;
  buttonSize?: number;
  // Navigation props
  hasPreviousVideo?: boolean;
  hasNextVideo?: boolean;
  onNavigateToPrevious?: () => void;
  onNavigateToNext?: () => void;
  // Minimize/PiP props
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  // Fullscreen callback
  onFullscreenChange?: (full: boolean) => void;
  // Autoplay callbacks
  isAutoplayEnabled?: boolean;
  onVideoFinished?: () => void;
  // Legacy props (for compatibility)
  captions?: any;
  chapters?: any;
  hideControlsTimeout?: number;
  theme?: string;
};

const DEFAULT_BUTTON_SIZE = 80;
/** Quick seek amount (ms) for double-tap */
const QUICK_MS = 10000;

/** Structured logger for this module */
const log = (...args: any[]) => {
  if (__DEV__) console.info("[Player]", ...args);
};

/**
 * VideoPlayer component
 */
const VideoPlayer: React.FC<Props> = ({
  sourceUrl,
  autoplay = true,
  buttonSize = DEFAULT_BUTTON_SIZE,
  // Navigation props with defaults
  hasPreviousVideo = false,
  hasNextVideo = false,
  onNavigateToPrevious = () => log("Previous video pressed (no handler)"),
  onNavigateToNext = () => log("Next video pressed (no handler)"),
  // Minimize props with defaults
  isMinimized = false,
  onToggleMinimize = () => log("Minimize/Restore pressed (no handler)"),
  // Fullscreen callback
  onFullscreenChange,
  // Autoplay props
  isAutoplayEnabled = true,
  onVideoFinished,
}) => {
  const videoRef = useRef<Video | null>(null);
  const lastTapRef = useRef<number>(0);

  // Autoplay state for next video
  const [autoplayEnabled, setAutoplayEnabled] = useState(true);
  
  // Notification state
  const [notificationVisible, setNotificationVisible] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  // Fullscreen state
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [dimensions, setDimensions] = useState(Dimensions.get("window"));
  
  // Preserve video state when switching fullscreen
  const [savedPosition, setSavedPosition] = useState(0);
  const [savedIsPlaying, setSavedIsPlaying] = useState(autoplay);

  const controller = usePlayPauseController({
    videoRef,
    autoplay,
    initialVisibleMs: 3000,
    autoHideMs: 3500,
    fadeDurationMs: 220,
    enableLogs: __DEV__,
  });

  // Handle orientation changes and window resize
  useEffect(() => {
    const subscription = Dimensions.addEventListener("change", ({ window }) => {
      setDimensions(window);
      log("[Player] Dimensions changed:", window.width, "x", window.height);
    });

    return () => subscription?.remove();
  }, []);

  // Defensive wrapper for calling video methods
  const safeCall = useCallback(
    async (fn: (v: Video) => Promise<void> | void) => {
      try {
        const ref = videoRef.current;
        if (!ref) {
          log("[Player] videoRef missing in safeCall");
          return;
        }
        await fn(ref);
      } catch (e) {
        console.warn("[Player] safeCall error:", e);
      }
    },
    []
  );

  /**
   * Handle taps on video area:
   * - Always trigger controller.onScreenTap() to reset overlay timers
   * - Detect double-tap (best-effort heuristic) to quick seek left/right
   */
  const onVideoAreaPress = useCallback(
    (evt: GestureResponderEvent) => {
      try {
        controller.onScreenTap();

        const now = Date.now();
        const last = lastTapRef.current;
        lastTapRef.current = now;

        if (now - last < 300) {
          // double-tap detected: quick seek
          const locX = (evt.nativeEvent as any).locationX;
          const pageX = (evt.nativeEvent as any).pageX;
          // Heuristic to determine left vs right (simple threshold)
          const isLeft =
            typeof locX === "number"
              ? locX < (evt.currentTarget as any)?.clientWidth / 2 ?? 200
              : typeof pageX === "number"
              ? pageX < 200
              : false;
          const offset = isLeft ? -QUICK_MS : QUICK_MS;
          log(
            "[Player] double-tap quickSeek",
            offset > 0 ? "forward" : "back",
            offset
          );

          safeCall(async (v) => {
            try {
              const s = (await v.getStatusAsync?.()) as AVPlaybackStatus | null;
              if (!s?.isLoaded || s.durationMillis == null) return;
              const newPos = Math.max(
                0,
                Math.min((s.positionMillis ?? 0) + offset, s.durationMillis)
              );
              await v.setPositionAsync(Math.floor(newPos));
              // interaction -> reset auto-hide timer
              controller.scheduleHideIfNeeded();
            } catch (e) {
              console.warn("[Player] quickSeek failed:", e);
            }
          });
        }
      } catch (e) {
        console.warn("[Player] onVideoAreaPress failure:", e);
      }
    },
    [controller, safeCall]
  );

  /** forward playback updates to controller and handle autoplay */
  const onPlaybackStatusUpdate = useCallback(
    (status: AVPlaybackStatus) => {
      try {
        controller.onPlaybackStatusUpdate(status);

        // Handle video finished for autoplay
        if (status.isLoaded && status.didJustFinish && !status.isLooping) {
          log("[Player] Video finished, didJustFinish:", status.didJustFinish);
          
          if (isAutoplayEnabled && hasNextVideo && onVideoFinished) {
            log("[Autoplay] Triggering next video");
            // Small delay to show finished state
            setTimeout(() => {
              onVideoFinished();
            }, 1000);
          } else if (!isAutoplayEnabled) {
            log("[Autoplay] Disabled, showing replay option");
          } else if (!hasNextVideo) {
            log("[Autoplay] No next video available");
          }
        }
      } catch (e) {
        console.warn("[Player] onPlaybackStatusUpdate forward failed:", e);
      }
    },
    [controller, isAutoplayEnabled, hasNextVideo, onVideoFinished]
  );

  const onCenterPress = useCallback(async () => {
    await controller.onCenterPress();
  }, [controller]);

  const onVideoError = useCallback(
    (e: any) => {
      console.error("[Player][expo-av] error:", e);
      controller.showImmediately(true);
    },
    [controller]
  );

  const handleToggleAutoplay = useCallback(() => {
    setAutoplayEnabled((prev) => {
      const newState = !prev;
      // Show notification with appropriate message
      setNotificationMessage(newState ? "Autoplay is on" : "Autoplay is off");
      setNotificationVisible(true);
      log("[Player] Autoplay toggled:", newState);
      return newState;
    });
  }, []);

  const handleNotificationDismiss = useCallback(() => {
    setNotificationVisible(false);
  }, []);

  const handleToggleFullscreen = useCallback(async () => {
    try {
      // ALWAYS save current state first (critical for both enter and exit)
      let currentPosition = savedPosition;
      let currentIsPlaying = savedIsPlaying;
      
      await safeCall(async (v) => {
        try {
          const status = await v.getStatusAsync();
          if (status.isLoaded) {
            currentPosition = status.positionMillis || 0;
            currentIsPlaying = status.isPlaying;
            setSavedPosition(currentPosition);
            setSavedIsPlaying(currentIsPlaying);
            log("[Player] Saved state - Position:", currentPosition, "Playing:", currentIsPlaying);
          }
        } catch (e) {
          log("[Player] Failed to save state:", e);
        }
      });
      
      if (!isFullscreen) {
        // Enter fullscreen
        log("[Player] Entering fullscreen");
        
        // Web: Use Fullscreen API
        if (Platform.OS === "web") {
          try {
            const docElement = document.documentElement as any;
            if (docElement.requestFullscreen) {
              await docElement.requestFullscreen();
            } else if (docElement.webkitRequestFullscreen) {
              await docElement.webkitRequestFullscreen();
            } else if (docElement.mozRequestFullScreen) {
              await docElement.mozRequestFullScreen();
            } else if (docElement.msRequestFullscreen) {
              await docElement.msRequestFullscreen();
            }
          } catch (e) {
            log("[Player] Web fullscreen API failed:", e);
          }
        } else {
          // Mobile: Hide status bar and lock orientation
          StatusBar.setHidden(true, "fade");
          
          try {
            await ScreenOrientation.lockAsync(
              ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT
            );
          } catch (e) {
            log("[Player] Orientation lock failed:", e);
          }
        }
        
        setIsFullscreen(true);
        controller.showImmediately(true);
        
        // Restore position and play state after entering fullscreen
        setTimeout(() => {
          safeCall(async (v) => {
            try {
              await v.setPositionAsync(currentPosition);
              log("[Player] Restored position:", currentPosition);
              
              // Preserve play/pause state
              if (currentIsPlaying) {
                await v.playAsync();
                log("[Player] Resumed playing");
              } else {
                await v.pauseAsync();
                log("[Player] Kept paused");
              }
            } catch (e) {
              log("[Player] Failed to restore state:", e);
            }
          });
        }, 200);
      } else {
        // Exit fullscreen
        log("[Player] Exiting fullscreen");
        
        // Web: Exit Fullscreen API
        if (Platform.OS === "web") {
          try {
            const doc = document as any;
            if (doc.exitFullscreen) {
              await doc.exitFullscreen();
            } else if (doc.webkitExitFullscreen) {
              await doc.webkitExitFullscreen();
            } else if (doc.mozCancelFullScreen) {
              await doc.mozCancelFullScreen();
            } else if (doc.msExitFullscreen) {
              await doc.msExitFullscreen();
            }
          } catch (e) {
            log("[Player] Web exit fullscreen failed:", e);
          }
        } else {
          // Mobile: Show status bar and unlock orientation
          StatusBar.setHidden(false, "fade");
          
          try {
            await ScreenOrientation.lockAsync(
              ScreenOrientation.OrientationLock.PORTRAIT_UP
            );
          } catch (e) {
            log("[Player] Orientation unlock failed:", e);
          }
        }
        
        setIsFullscreen(false);
        controller.showImmediately(true);
        
        // Restore position and play state after exiting fullscreen
        setTimeout(() => {
          safeCall(async (v) => {
            try {
              await v.setPositionAsync(currentPosition);
              log("[Player] Restored position after exit:", currentPosition);
              
              // Preserve play/pause state
              if (currentIsPlaying) {
                await v.playAsync();
                log("[Player] Resumed playing after exit");
              } else {
                await v.pauseAsync();
                log("[Player] Kept paused after exit");
              }
            } catch (e) {
              log("[Player] Failed to restore state after exit:", e);
            }
          });
        }, 200);
      }
    } catch (e) {
      console.error("[Player] Fullscreen toggle error:", e);
    }
  }, [isFullscreen, controller, savedPosition, savedIsPlaying, safeCall]);

  // Handle minimize - exit fullscreen first if needed
  const handleMinimize = useCallback(async () => {
    if (isFullscreen) {
      // Exit fullscreen first, then minimize
      log("[Player] Exiting fullscreen before minimize");
      await handleToggleFullscreen();
      // Small delay to let fullscreen exit complete
      setTimeout(() => {
        onToggleMinimize();
      }, 300);
    } else {
      // Already in portrait, just minimize
      onToggleMinimize();
    }
  }, [isFullscreen, handleToggleFullscreen, onToggleMinimize]);

  // Handle keyboard events (Escape to exit fullscreen on web)
  useEffect(() => {
    if (Platform.OS === "web") {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape" && isFullscreen) {
          handleToggleFullscreen();
        } else if (e.key === "f" || e.key === "F") {
          handleToggleFullscreen();
        }
      };

      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }
  }, [isFullscreen, handleToggleFullscreen]);

  // Listen for fullscreen changes on web (user using browser controls)
  useEffect(() => {
    if (Platform.OS === "web") {
      const handleFullscreenChange = () => {
        const doc = document as any;
        const isCurrentlyFullscreen = !!(
          doc.fullscreenElement ||
          doc.webkitFullscreenElement ||
          doc.mozFullScreenElement ||
          doc.msFullscreenElement
        );
        
        if (isCurrentlyFullscreen !== isFullscreen) {
          setIsFullscreen(isCurrentlyFullscreen);
          controller.showImmediately(true);
        }
      };

      document.addEventListener("fullscreenchange", handleFullscreenChange);
      document.addEventListener("webkitfullscreenchange", handleFullscreenChange);
      document.addEventListener("mozfullscreenchange", handleFullscreenChange);
      document.addEventListener("MSFullscreenChange", handleFullscreenChange);

      return () => {
        document.removeEventListener("fullscreenchange", handleFullscreenChange);
        document.removeEventListener("webkitfullscreenchange", handleFullscreenChange);
        document.removeEventListener("mozfullscreenchange", handleFullscreenChange);
        document.removeEventListener("MSFullscreenChange", handleFullscreenChange);
      };
    }
  }, [isFullscreen, controller]);

  // Notify parent of fullscreen changes
  useEffect(() => {
    if (onFullscreenChange) {
      onFullscreenChange(isFullscreen);
    }
  }, [isFullscreen, onFullscreenChange]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      // Reset orientation and status bar on unmount
      if (isFullscreen) {
        if (Platform.OS === "web") {
          // Exit fullscreen on web
          const doc = document as any;
          if (doc.exitFullscreen) doc.exitFullscreen().catch(() => {});
          else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
        } else {
          // Reset mobile
          StatusBar.setHidden(false, "fade");
          ScreenOrientation.unlockAsync().catch(() => {});
        }
      }
    };
  }, [isFullscreen]);

  // Compute responsive wrapper style with proper React Native fullscreen
  const wrapperStyle = isFullscreen
    ? {
        position: "absolute" as const,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: dimensions.width,
        height: dimensions.height,
        zIndex: 9999,
        backgroundColor: "#000",
        flex: 1,
      }
    : styles.wrapper;

  // Video style for proper centering and filling
  // Use cover in fullscreen to eliminate black bars
  const videoStyle = isFullscreen
    ? {
        position: "absolute" as const,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "#000",
      }
    : styles.video;
  
  // ResizeMode changes based on fullscreen state
  // Use "stretch" in fullscreen to force 100% coverage
  const resizeMode = isFullscreen ? "stretch" : "contain";

  // Touchable style for proper fullscreen coverage
  const touchableStyle = isFullscreen
    ? {
        position: "absolute" as const,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "#000",
      }
    : styles.touchable;

  // Render fullscreen content
  const renderPlayerContent = () => (
    <>
      <TouchableOpacity
        activeOpacity={1}
        onPress={onVideoAreaPress}
        style={touchableStyle}
        accessibilityLabel="Tap to show controls"
      >
        <Video
          ref={videoRef}
          style={videoStyle}
          source={{ uri: sourceUrl }}
          resizeMode={resizeMode}
          shouldPlay={autoplay}
          onPlaybackStatusUpdate={onPlaybackStatusUpdate}
          onError={onVideoError}
          useNativeControls={false}
        />
      </TouchableOpacity>

      {/* Center Control Buttons overlay (Previous, Play/Pause, Next) */}
      <View pointerEvents="box-none" style={styles.centerOverlay}>
        <View style={styles.controlRow}>
          {/* Previous Video Button */}
          <PreviousVideoButton
            opacity={controller.opacity}
            disabled={!hasPreviousVideo}
            onPress={onNavigateToPrevious}
            size={buttonSize * 0.8} // 80% of play button size (YouTube proportions)
            style={{ position: "relative", marginRight: 24 }}
          />

          {/* Play/Pause Button */}
          <PlayPauseButton
            opacity={controller.opacity}
            isPlaying={controller.isPlaying}
            size={buttonSize}
            onPress={onCenterPress}
            style={{ position: "relative" }}
          />

          {/* Next Video Button */}
          <NextVideoButton
            opacity={controller.opacity}
            disabled={!hasNextVideo}
            onPress={onNavigateToNext}
            size={buttonSize * 0.8} // 80% of play button size (YouTube proportions)
            style={{ position: "relative", marginLeft: 24 }}
          />
        </View>
      </View>

      {/* Minimize/Restore Button - Top Left (YouTube position) */}
      <View 
        pointerEvents="box-none" 
        style={[
          styles.topLeftOverlay,
          isFullscreen && {
            position: "absolute",
            top: 20,
            left: 20,
            zIndex: 10000,
          }
        ]}
      >
        <View pointerEvents="auto">
          <MinimizeButton
            opacity={controller.opacity}
            isMinimized={isMinimized}
            onPress={handleMinimize}
            size={isFullscreen ? 56 : (buttonSize * 0.6)} // Larger in fullscreen
            style={{ position: "relative" }}
          />
        </View>
      </View>

      {/* Autoplay Toggle - Top Right (YouTube 2025 position) */}
      <View pointerEvents="box-none" style={styles.topRightOverlay}>
        <View pointerEvents="auto">
          <AutoplayToggle
            opacity={controller.opacity}
            autoplayEnabled={autoplayEnabled}
            onToggle={handleToggleAutoplay}
            size={32}
            disabled={!hasNextVideo}
          />
        </View>
      </View>

      {/* Autoplay Notification - Shows "Autoplay is on/off" */}
      <AutoplayNotification
        visible={notificationVisible}
        message={notificationMessage}
        onDismiss={handleNotificationDismiss}
      />

      {/* Fullscreen Button - Bottom Right (YouTube position) */}
      <View 
        pointerEvents="box-none" 
        style={[
          styles.bottomRightOverlay,
          isFullscreen && {
            position: "absolute",
            bottom: 20,
            right: 20,
            zIndex: 10000,
          }
        ]}
      >
        <View pointerEvents="auto">
          <FullscreenButton
            opacity={controller.opacity}
            isFullscreen={isFullscreen}
            onToggle={handleToggleFullscreen}
            size={isFullscreen ? 56 : 48}
          />
        </View>
      </View>

      {/* Debug overlay removed for cleaner UI */}
    </>
  );

  // Use Modal for true fullscreen on mobile
  if (isFullscreen && Platform.OS !== "web") {
    return (
      <Modal
        visible={true}
        animationType="none"
        statusBarTranslucent={true}
        transparent={false}
        supportedOrientations={['landscape', 'portrait']}
        onRequestClose={handleToggleFullscreen}
      >
        <View style={styles.fullscreenModalContainer}>
          {renderPlayerContent()}
        </View>
      </Modal>
    );
  }

  // Normal render or web fullscreen
  return (
    <View style={wrapperStyle as any}>
      {renderPlayerContent()}
    </View>
  );
};

export default VideoPlayer;

const styles = StyleSheet.create({
  wrapper: {
    width: "100%",
    aspectRatio: 16 / 9,
    backgroundColor: "#000",
    position: "relative",
    overflow: "hidden",
    margin: 0,
    padding: 0,
  },
  touchable: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
  video: {
    flex: 1,
    width: "100%",
    height: "100%",
    backgroundColor: "#000",
  },
  centerOverlay: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    pointerEvents: "box-none",
  },
  controlRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    pointerEvents: "box-none",
  },
  topLeftOverlay: {
    position: "absolute",
    top: 12,
    left: 12,
    zIndex: 1001,
    pointerEvents: "box-none",
  },
  topRightOverlay: {
    position: "absolute",
    top: 12,
    right: 12,
    zIndex: 1001,
    pointerEvents: "box-none",
  },
  bottomRightOverlay: {
    position: "absolute",
    bottom: 12,
    right: 12,
    zIndex: 1001,
    pointerEvents: "box-none",
  },
  fullscreenModalContainer: {
    flex: 1,
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "#000",
    margin: 0,
    padding: 0,
  },
});