/**
 * components/VideoFeed/VideoFeed.tsx
 * 
 * YouTube 2025-style scrollable video feed
 * - Infinite scroll with pagination
 * - Lazy loading and performance optimization
 * - Responsive grid/list layout
 * - Pull-to-refresh support
 * - Error handling and retry logic
 * 
 * Dependencies: react, react-native, expo-router
 */

import React, { useState, useCallback, useEffect, useMemo } from "react";
import {
  FlatList,
  View,
  Text,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Pressable,
  useColorScheme,
  useWindowDimensions,
  Platform,
} from "react-native";
import VideoCard from "./VideoCard";
import VideoCardSkeleton from "./VideoCardSkeleton";
import type { VideoMetadata } from "../../types/video";
import { fetchVideoFeed } from "../../services/videoService";
import Logger from "../../utils/Logger";

interface VideoFeedProps {
  initialVideos?: VideoMetadata[];
  pageSize?: number;
  variant?: "list" | "grid" | "auto";
  onVideoPress?: (video: VideoMetadata) => void;
  onVideosLoaded?: (videos: VideoMetadata[]) => void;
}

const VideoFeed: React.FC<VideoFeedProps> = ({
  initialVideos = [],
  pageSize = 10,
  variant = "auto",
  onVideoPress,
  onVideosLoaded,
}) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const { width } = useWindowDimensions();

  // Determine layout variant based on screen width
  const layoutVariant = useMemo(() => {
    if (variant === "auto") {
      // Responsive breakpoints (YouTube-style)
      if (width >= 1024) return "grid"; // Desktop: grid
      if (width >= 768) return "grid";  // Tablet: grid
      return "list";                     // Mobile: list
    }
    return variant;
  }, [variant, width]);

  // Number of columns for grid layout
  const numColumns = useMemo(() => {
    if (layoutVariant === "list") return 1;
    if (width >= 1024) return 3; // Desktop: 3 columns
    if (width >= 768) return 2;  // Tablet: 2 columns
    return 1;
  }, [layoutVariant, width]);

  // State management
  const [videos, setVideos] = useState<VideoMetadata[]>(initialVideos);
  const [loading, setLoading] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [loadingMore, setLoadingMore] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [initialLoad, setInitialLoad] = useState<boolean>(true);

  /**
   * Load initial videos
   */
  const loadInitialVideos = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      Logger.info("[VideoFeed] Loading initial videos");

      const response = await fetchVideoFeed(0, pageSize);
      
      setVideos(response.videos);
      setHasMore(response.hasMore);
      setPage(1);
      setInitialLoad(false);

      // Notify parent of loaded videos
      if (onVideosLoaded) {
        onVideosLoaded(response.videos);
      }

      Logger.info(`[VideoFeed] Loaded ${response.videos.length} videos`);
    } catch (err: any) {
      const errorMsg = err?.message || "Failed to load videos";
      setError(errorMsg);
      Logger.error("[VideoFeed] Initial load failed:", err);
    } finally {
      setLoading(false);
    }
  }, [pageSize]);

  /**
   * Load more videos (pagination)
   */
  const loadMoreVideos = useCallback(async () => {
    if (loadingMore || !hasMore || loading) {
      return;
    }

    try {
      setLoadingMore(true);
      Logger.info(`[VideoFeed] Loading page ${page}`);

      const response = await fetchVideoFeed(page, pageSize);

      const updatedVideos = [...videos, ...response.videos];
      setVideos(updatedVideos);
      setHasMore(response.hasMore);
      setPage((p) => p + 1);

      // Update global list
      if (onVideosLoaded) {
        onVideosLoaded(updatedVideos);
      }

      Logger.info(`[VideoFeed] Loaded ${response.videos.length} more videos`);
    } catch (err: any) {
      Logger.error("[VideoFeed] Load more failed:", err);
      // Don't show error for pagination failures, just stop loading
    } finally {
      setLoadingMore(false);
    }
  }, [page, pageSize, loadingMore, hasMore, loading]);

  /**
   * Pull to refresh
   */
  const handleRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      setError(null);
      Logger.info("[VideoFeed] Refreshing feed");

      const response = await fetchVideoFeed(0, pageSize);

      setVideos(response.videos);
      setHasMore(response.hasMore);
      setPage(1);

      Logger.info("[VideoFeed] Refresh complete");
    } catch (err: any) {
      const errorMsg = err?.message || "Failed to refresh";
      setError(errorMsg);
      Logger.error("[VideoFeed] Refresh failed:", err);
    } finally {
      setRefreshing(false);
    }
  }, [pageSize]);

  /**
   * Retry after error
   */
  const handleRetry = useCallback(() => {
    loadInitialVideos();
  }, [loadInitialVideos]);

  // Load initial videos on mount
  useEffect(() => {
    if (initialVideos.length === 0) {
      loadInitialVideos();
    } else {
      setInitialLoad(false);
    }
  }, []);

  /**
   * Render video card item
   */
  const renderItem = useCallback(
    ({ item }: { item: VideoMetadata }) => (
      <VideoCard
        video={item}
        variant={layoutVariant}
        onPress={onVideoPress}
      />
    ),
    [layoutVariant, onVideoPress]
  );

  /**
   * Key extractor for FlatList optimization
   */
  const keyExtractor = useCallback((item: VideoMetadata) => item.id, []);

  /**
   * Render footer (loading more indicator)
   */
  const renderFooter = useCallback(() => {
    if (!loadingMore) return null;

    return (
      <View style={styles.footerLoader}>
        <ActivityIndicator size="small" color="#0ea5ff" />
        <Text style={[styles.footerText, { color: isDark ? "#AAAAAA" : "#606060" }]}>
          Loading more videos...
        </Text>
      </View>
    );
  }, [loadingMore, isDark]);

  /**
   * Render empty state
   */
  const renderEmpty = useCallback(() => {
    if (loading || initialLoad) {
      // Show skeletons during initial load
      return (
        <View style={styles.skeletonContainer}>
          {Array.from({ length: 5 }).map((_, i) => (
            <VideoCardSkeleton key={`skeleton-${i}`} variant={layoutVariant} />
          ))}
        </View>
      );
    }

    if (error) {
      // Show error state
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>⚠️</Text>
          <Text style={[styles.emptyTitle, { color: isDark ? "#FFFFFF" : "#0F0F0F" }]}>
            Unable to load videos
          </Text>
          <Text style={[styles.emptyText, { color: isDark ? "#AAAAAA" : "#606060" }]}>
            {error}
          </Text>
          <Pressable style={styles.retryButton} onPress={handleRetry}>
            <Text style={styles.retryButtonText}>Try Again</Text>
          </Pressable>
        </View>
      );
    }

    // No videos
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>📹</Text>
        <Text style={[styles.emptyTitle, { color: isDark ? "#FFFFFF" : "#0F0F0F" }]}>
          No videos yet
        </Text>
        <Text style={[styles.emptyText, { color: isDark ? "#AAAAAA" : "#606060" }]}>
          Check back later for new content
        </Text>
      </View>
    );
  }, [loading, initialLoad, error, isDark, layoutVariant, handleRetry]);

  /**
   * Handle end reached (infinite scroll)
   */
  const handleEndReached = useCallback(() => {
    if (hasMore && !loadingMore && !loading) {
      loadMoreVideos();
    }
  }, [hasMore, loadingMore, loading, loadMoreVideos]);

  /**
   * Get item layout for optimization (reduce layout calculations)
   */
  const getItemLayout = useCallback(
    (_: any, index: number) => {
      const ITEM_HEIGHT = layoutVariant === "grid" ? 220 : 240;
      return {
        length: ITEM_HEIGHT,
        offset: ITEM_HEIGHT * index,
        index,
      };
    },
    [layoutVariant]
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={videos}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        numColumns={numColumns}
        key={`${layoutVariant}-${numColumns}`} // Force re-render on layout change
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        onEndReached={handleEndReached}
        onEndReachedThreshold={0.5}
        getItemLayout={getItemLayout}
        maxToRenderPerBatch={10}
        updateCellsBatchingPeriod={50}
        windowSize={10}
        removeClippedSubviews={Platform.OS === "android"}
        ListEmptyComponent={renderEmpty}
        ListFooterComponent={renderFooter}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor="#0ea5ff"
            colors={["#0ea5ff"]}
            title="Pull to refresh"
            titleColor={isDark ? "#AAAAAA" : "#606060"}
          />
        }
        initialNumToRender={5}
        accessible
        accessibilityLabel="Video feed"
        accessibilityHint="Scroll to see more videos"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingTop: 8,
    paddingBottom: 24,
  },
  skeletonContainer: {
    paddingTop: 8,
  },
  footerLoader: {
    paddingVertical: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  footerText: {
    marginTop: 8,
    fontSize: 13,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    paddingVertical: 64,
    minHeight: 400,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 8,
    textAlign: "center",
  },
  emptyText: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
    marginBottom: 24,
  },
  retryButton: {
    backgroundColor: "#0ea5ff",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    elevation: 2,
    ...Platform.select({
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      web: {
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
      },
    }),
  },
  retryButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
  },
});

export default React.memo(VideoFeed);

