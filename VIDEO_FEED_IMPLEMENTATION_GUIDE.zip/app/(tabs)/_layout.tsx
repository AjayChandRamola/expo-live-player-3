// -----------------------------------------------------------------------------
// File: app/(tabs)/_layout.tsx
// -----------------------------------------------------------------------------
// ✅ Expo Router Tabs Layout — Safe Area + Theme Integrated
// -----------------------------------------------------------------------------

import React, { useEffect } from "react";
import { Tabs } from "expo-router";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Logger from "../../utils/Logger";
import { useThemeColors } from "../../constants/theme"; // ✅ correct path

export default function TabsLayout() {
  const theme = useThemeColors();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    Logger.info(`[Tabs] Mounted with theme background: ${theme.background}`);
    return () => Logger.info("[Tabs] Unmounted.");
  }, [theme.background]);

  return (
    <Tabs
      screenOptions={{
        // ---------------------- Header styling ----------------------
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomWidth: 0,
          shadowOpacity: 0.1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: "800",
          fontSize: 18,
        },

        // ---------------------- Tab styling ----------------------
        tabBarActiveTintColor: theme.tint,
        tabBarInactiveTintColor: theme.icon,
        tabBarStyle: {
          backgroundColor: theme.background,
          borderTopColor: theme.border,
          borderTopWidth: 0.5,

          // ✅ Dynamic safe area padding
          height: 60 + insets.bottom,
          paddingBottom: insets.bottom > 0 ? insets.bottom / 2 : 6,
        },
        tabBarLabelStyle: { fontSize: 12, fontWeight: "600" },
      }}
    >
      {/* ---------------------- HOME ---------------------- */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Yagna Videos",
          tabBarLabel: "Home",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="home-variant"
              size={size}
              color={color}
            />
          ),
          headerShown: false,
        }}
      />

      {/* ---------------------- EXPLORE ---------------------- */}
      <Tabs.Screen
        name="explore"
        options={{
          title: "Explore",
          tabBarLabel: "Explore",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="magnify"
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* ---------------------- SETTINGS ---------------------- */}
      <Tabs.Screen
        name="settings"
        options={{
          title: "Settings",
          tabBarLabel: "Settings",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="cog-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tabs>
  );
}
