/**
 * app/(tabs)/index.tsx
 * 
 * Home screen with YouTube 2025-style video feed
 * - Scrollable video cards with thumbnails and metadata
 * - Infinite scroll with lazy loading
 * - Search functionality
 * - Responsive grid/list layout
 * - Pull-to-refresh support
 * 
 * Production-ready Expo Managed Workflow implementation
 */

import React, { useCallback, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  useColorScheme,
  Platform,
  ScrollView,
} from "react-native";
import { useRouter } from "expo-router";
import { VideoFeed } from "../../components/VideoFeed";
import type { VideoMetadata } from "../../types/video";
import { useVideoPlayerContext } from "../../contexts/VideoPlayerContext";
import Logger from "../../utils/Logger";
import { Colors } from "../../constants/theme";

/**
 * Sanitize user input to prevent XSS and injection attacks
 */
const sanitizeText = (t: unknown, max = 200): string =>
  typeof t === "string"
    ? t.replace(/[\u0000-\u001F\u007F]/g, "").trim().slice(0, max)
    : "";

/**
 * HomeScreen - YouTube 2025-style video feed
 */
export default function HomeScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const theme = isDark ? Colors.dark : Colors.light;

  // Global video context
  const { setVideoList, playVideoById, saveHomeScrollPosition } = useVideoPlayerContext();

  const [query, setQuery] = useState("");
  const [isSearchMode, setIsSearchMode] = useState(false);
  const [allVideos, setAllVideos] = useState<VideoMetadata[]>([]);

  // Log mount
  Logger.info("[HomeScreen] Mounted with theme:", colorScheme);

  /**
   * Update global video list when videos are loaded
   */
  const handleVideosLoaded = useCallback(
    (videos: VideoMetadata[]) => {
      setAllVideos(videos);
      setVideoList(videos);
      Logger.info(`[HomeScreen] Updated global video list: ${videos.length} videos`);
    },
    [setVideoList]
  );

  /**
   * Handle video card press
   */
  const handleVideoPress = useCallback(
    (video: VideoMetadata) => {
      try {
        const safeId = sanitizeText(video.id, 64);
        if (!safeId) {
          Logger.warn("[HomeScreen] Invalid video ID");
          return;
        }

        // Update global state with selected video
        playVideoById(safeId);
        
        Logger.info(`[HomeScreen] Navigating to video: ${safeId}`);
        router.push(`/video/${encodeURIComponent(safeId)}`);
      } catch (error) {
        Logger.error("[HomeScreen] Navigation failed:", error);
      }
    },
    [router, playVideoById]
  );

  /**
   * Handle search submit
   */
  const handleSearch = useCallback(() => {
    const trimmed = query.trim();
    if (trimmed) {
      setIsSearchMode(true);
      Logger.info(`[HomeScreen] Search initiated: "${trimmed}"`);
    } else {
      setIsSearchMode(false);
    }
  }, [query]);

  /**
   * Clear search
   */
  const handleClearSearch = useCallback(() => {
    setQuery("");
    setIsSearchMode(false);
    Logger.info("[HomeScreen] Search cleared");
  }, []);

  return (
    <View style={[styles.root, { backgroundColor: theme.background }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text 
          style={[styles.headerTitle, { color: theme.text }]}
          accessibilityRole="header"
        >
          📺 Yagna Vishnu Bhagwan
        </Text>
        <Text style={[styles.headerSubtitle, { color: isDark ? "#AAAAAA" : "#606060" }]}>
          Divya Darshan
        </Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchRow}>
          <TextInput
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={handleSearch}
            placeholder="Search videos, channels..."
            placeholderTextColor={isDark ? "#666666" : "#999999"}
            style={[
              styles.searchInput,
              {
                color: theme.text,
                backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.05)",
                borderColor: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.12)",
              },
            ]}
            returnKeyType="search"
            clearButtonMode="while-editing"
            accessible
            accessibilityLabel="Search videos"
            accessibilityHint="Type to search for videos or channels"
          />
          {query.length > 0 && (
            <Pressable 
              onPress={handleClearSearch} 
              style={styles.clearBtn}
              accessible
              accessibilityLabel="Clear search"
              accessibilityRole="button"
            >
              <Text style={[styles.clearText, { color: theme.tint }]}>✕</Text>
            </Pressable>
          )}
        </View>
      </View>

      {/* Video Feed */}
      <VideoFeed
        pageSize={10}
        variant="auto"
        onVideoPress={handleVideoPress}
        onVideosLoaded={handleVideosLoaded}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: Platform.OS === "ios" ? 8 : 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    marginBottom: 2,
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    fontWeight: "500",
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    position: "relative",
  },
  searchInput: {
    flex: 1,
    height: 44,
    borderRadius: 22,
    paddingHorizontal: 18,
    paddingRight: 50,
    fontSize: 15,
    borderWidth: 1,
    ...Platform.select({
      web: {
        outlineStyle: "none",
      },
    }),
  },
  clearBtn: {
    position: "absolute",
    right: 8,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(128, 128, 128, 0.2)",
  },
  clearText: {
    fontSize: 18,
    fontWeight: "600",
  },
});
