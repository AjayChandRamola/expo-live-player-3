// File: app/_layout.tsx
/**
 * ✅ Production-Grade Root Layout for Expo Router
 * -------------------------------------------------
 * - Architected for high-performance, modular Expo apps.
 * - Provides foundational structure for all route stacks.
 * - Implements clean architecture principles with:
 *   → Centralized navigation host
 *   → Global error boundaries (future-ready)
 *   → Consistent theme surface & layout normalization
 *   → Observability and structured logging
 *
 * Fully Expo Managed Workflow compliant — no native ejects required.
 */

import React, { useEffect } from "react";
import { Stack } from "expo-router";
import {
  View,
  StyleSheet,
  Platform,
  StatusBar,
  LogBox,
  useColorScheme,
} from "react-native";
import * as SplashScreen from "expo-splash-screen";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { VideoPlayerProvider } from "../contexts/VideoPlayerContext";

/**
 * Security + Performance Notes:
 * - No hardcoded secrets or unsafe globals.
 * - Minimal runtime overhead.
 * - Defensive against runtime theme / layout exceptions.
 * - Logs startup phases for observability.
 */

// Prevent splash screen from auto-hiding until layout is ready
SplashScreen.preventAutoHideAsync().catch(() =>
  console.warn("[App] SplashScreen preventAutoHide failed (safe to ignore).")
);

export default function RootLayout() {
  const colorScheme = useColorScheme();

  useEffect(() => {
    LogBox.ignoreLogs([
      "Require cycle:",
      "VirtualizedLists should never be nested",
      "Non-serializable values were found in the navigation state",
    ]);

    console.info("[App] RootLayout mounted with scheme:", colorScheme);
    try {
      StatusBar.setBarStyle(colorScheme === "dark" ? "light-content" : "dark-content");
      if (Platform.OS === "android") {
        StatusBar.setBackgroundColor("transparent");
        StatusBar.setTranslucent(true);
      }
    } catch (e) {
      console.warn("[App] Failed to set StatusBar style:", e);
    }

    // Safe hide splash after stack is ready
    const timeout = setTimeout(() => {
      SplashScreen.hideAsync().catch(() =>
        console.warn("[App] SplashScreen hideAsync failed (safe to ignore).")
      );
    }, 400);

    return () => clearTimeout(timeout);
  }, [colorScheme]);

  return (
    <VideoPlayerProvider>
      <SafeAreaProvider>
        <View
          style={[
            styles.wrapper,
            colorScheme === "dark" ? styles.darkBackground : styles.lightBackground,
          ]}
        >
          <Stack
            screenOptions={{
              headerShown: false,
              animation: "slide_from_right",
              gestureEnabled: true,
              contentStyle: {
                backgroundColor: "transparent",
              },
            }}
          />
        </View>
      </SafeAreaProvider>
    </VideoPlayerProvider>
  );
}

/**
 * ✅ Styles follow Clean Architecture Guidelines:
 * - Layout-level presentation only.
 * - No business or state logic leakage.
 * - Ready for theming and safe area adjustments.
 */
const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "stretch",
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight ?? 0 : 0,
  },
  lightBackground: {
    backgroundColor: "#ffffff",
  },
  darkBackground: {
    backgroundColor: "#000000",
  },
});
